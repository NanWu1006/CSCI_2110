Compiling:

Compile with ant using command 'ant build' in THIS directory.

The compiled class files will be in out/classes


==============================
HOW TO RUN THE TEST:
==============================

ant test




Run:

To run class files, use java, following the PACKAGE_NAME.CLASS_NAME.

Package Name is the directory name, such as Q1, Q2, Q3.

Class name is the filename inside these directories.

For example, I am running the 'Test' class for Question 1

1. cd out/classes
2. java Q1.Test

For example, I am running the 'QuestionFour' class from Q4

1. cd out/classes
2. java Q4.QuestionFour


B00696964 Diqi Zeng
