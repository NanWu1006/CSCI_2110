package Q5;

/**
 * Created by KanzakiMirai on 1/12/16.
 */

/**
 * A test class for Q5
 *
 * @author Diqi Zeng
 */
public class Test {
    public static void main(String[] args) {
        System.out.println(QuestionFive.removeDuplicates("SBBBBBBBBK"));

        System.out.println(QuestionFive.anagram("AAB", "ABA"));

        System.out.println("MyNameIsDickyDesu".contains("Dicky"));

        System.out.println(QuestionFive.isRotation("waterbottle", "erbottlewat"));
    }
}